const mapDBToModel = ({
  id,
  name,
  year,
  username,
}) => ({
  id,
  name,
  year,
  username,
});

module.exports = { mapDBToModel };
